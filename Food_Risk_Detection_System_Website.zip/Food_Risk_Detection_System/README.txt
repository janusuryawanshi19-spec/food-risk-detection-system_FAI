FOOD RISK DETECTION SYSTEM — WEBSITE

Files:
- index.html: webpage structure and form
- style.css: responsive styling
- script.js: rule-based risk scoring and results

How to run:
1. Extract the ZIP file.
2. Open the extracted folder.
3. Double-click index.html to open it in Chrome, Edge, or another browser.
4. Enter the food details and click "Assess Food Risk".

Project note:
This is a simple educational, rule-based demonstration for a Foundation of AI micro project. It does not use a trained machine-learning model, live food databases, or laboratory testing. The risk result is only a basic estimate and cannot guarantee food safety.
