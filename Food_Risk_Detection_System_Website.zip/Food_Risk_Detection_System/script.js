const form = document.getElementById('foodForm');
const result = document.getElementById('result');
const resultTitle = document.getElementById('resultTitle');
const resultSummary = document.getElementById('resultSummary');
const riskBadge = document.getElementById('riskBadge');
const reasonList = document.getElementById('reasonList');
const recommendation = document.getElementById('recommendation');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const foodName = document.getElementById('foodName').value.trim();
  const category = document.getElementById('category').value;
  const expiry = document.getElementById('expiry').value;
  const storage = document.getElementById('storage').value;
  const spoilage = document.getElementById('spoilage').value;
  const time = document.getElementById('time').value;

  // Simple rule-based scoring for an educational Foundation of AI demonstration.
  let score = 0;
  const reasons = [];

  if (expiry === 'expired') {
    score += 4;
    reasons.push('The food is marked as past its expiry / use-by date.');
  } else if (expiry === 'unknown') {
    score += 1;
    reasons.push('The date is unknown, so extra caution is appropriate.');
  }

  if (storage === 'poor') {
    score += 3;
    reasons.push('The food may not have been stored under recommended conditions.');
  } else if (storage === 'unknown') {
    score += 1;
    reasons.push('The storage conditions are uncertain.');
  }

  if (spoilage === 'yes') {
    score += 5;
    reasons.push('Visible spoilage or an unusual smell was reported.');
  } else if (spoilage === 'unknown') {
    score += 1;
    reasons.push('The condition of the food is uncertain.');
  }

  if (category === 'perishable' && time === 'long') {
    score += 4;
    reasons.push('Perishable food was left unrefrigerated for 2 hours or more.');
  } else if (category === 'perishable' && time === 'na') {
    score += 1;
    reasons.push('The time spent unrefrigerated is unknown.');
  } else if (category !== 'perishable' && time === 'long') {
    reasons.push('The unrefrigerated-time answer was noted; its relevance depends on the food and label instructions.');
  }

  let level, title, summary, advice, badgeClass;
  if (score >= 5) {
    level = 'High Risk';
    title = `${foodName}: High Risk`;
    summary = 'The information entered includes one or more significant warning signs.';
    advice = 'Do not eat the food. Safely discard it and clean any surfaces or containers that it contacted. Follow local food-safety guidance.';
    badgeClass = 'high';
  } else if (score >= 2) {
    level = 'Moderate Risk';
    title = `${foodName}: Moderate Risk`;
    summary = 'Some uncertainty or warning signs were reported. This tool cannot confirm that the food is safe.';
    advice = 'Check the label and storage instructions. If the food is perishable and its safety is uncertain, do not taste it; discard it when in doubt.';
    badgeClass = 'medium';
  } else {
    level = 'Lower Indicated Risk';
    title = `${foodName}: Lower Indicated Risk`;
    summary = 'Few warning signs were selected, but this result does not guarantee the food is safe.';
    advice = 'Continue to follow the product label, safe handling, and storage instructions. Do not rely on smell or appearance alone.';
    badgeClass = '';
  }

  if (reasons.length === 0) {
    reasons.push('No major warning signs were selected in the form.');
  }

  resultTitle.textContent = title;
  resultSummary.textContent = summary;
  riskBadge.textContent = level;
  riskBadge.className = `badge ${badgeClass}`.trim();
  reasonList.replaceChildren();
  reasons.forEach((reason) => {
    const li = document.createElement('li');
    li.textContent = reason;
    reasonList.appendChild(li);
  });
  recommendation.textContent = advice;
  result.classList.remove('hidden');
  result.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

form.addEventListener('reset', () => {
  result.classList.add('hidden');
});
